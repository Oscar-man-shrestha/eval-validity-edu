# OSF / Zenodo deposit pack for `prereg-v1`

Local git tag is already created. This file is a **deposit helper** (not part of the locked hash set). Fill the DOI/URL after registration, then run `--touch-test` once.

## Git lock (already done locally)

| Item | Value |
| --- | --- |
| Tag | `prereg-v1` |
| Tag object | `cd7ebbc97a36bc0bb49261a5dbf3f67f2da97300` |
| Commit | `29e98ef791139e4c095c33c931fe219f027345ab` |
| Branch | `audit/verify-all-phases` |
| Remote | `https://github.com/Hisana-07/neurotrace-dag.git` |

Push (if not already):

```bash
git push origin audit/verify-all-phases
git push origin prereg-v1
```

## Attach these files to the registration

From the tagged commit (also zipped at `docs/osf_prereg_v1_packet.zip`):

1. `docs/PREREGISTRATION.md`
2. `docs/PREREGISTRATION_REPLICATION.md`
3. `docs/DEVIATIONS.md`
4. `outputs_junyi/phases/prereg_v1_locked_hashes.json` (optional but recommended)

## Paste-ready registration abstract

```
NeuroTrace-DAG confirmatory preregistration (prereg-v1).

Primary claim: a dataset satisfies H-rev iff native and cluster unit verdicts for
paired GRU−Markov non-repeat Recall@5 are both supported_* with opposite signs;
project claim = at least one such dataset.

Family: m_planned = 6 (3 datasets × {native, cluster}); Bonferroni CI level
1 − 0.05/m; N/A cells reduce m. The m = 6 Bonferroni level remains valid for
Junyi/ASSISTments cluster cells because those cells use the two-method
intersection rule (text and co-occurrence must share the same supported_*
label), yielding one registered verdict per cell rather than two family members.

GRU confirmatory seeds: 20261101, 20261102, 20261103.
Holdout: freeze learner partition seed 20261004.
Touch-test: single post-registration run of
scripts/run_freeze_partition_replication.py --touch-test; a second run requires
TOUCH_TEST_OVERRIDE: in docs/DEVIATIONS.md.

Exploratory ranking, H-rep, graph, and forgetting are out of confirmatory scope.
Git tag: prereg-v1 @ 29e98ef791139e4c095c33c931fe219f027345ab
```

## SHA-256 table (paste into registration)

| File | SHA-256 |
| --- | --- |
| `outputs_junyi/phases/probe_freeze.json` | `28a8248a1664f0e3dcf2a833be3e20f8e2b94bd457d1f4073f3e45095e4ffaff` |
| `scripts/run_freeze_partition_replication.py` | `09b419a5aaaac1326965ef03826e04eaef3c05ecb4cb45070ab50167f6c394fe` |
| `outputs_junyi/phases/dual_clustering.json` | `6c98f9e301ea0566165b492bdc179d9b2444f62504cc2de548778b48a2517923` |
| `cluster_maps/junyi_timed_{text,item}_to_cluster.json` | `be9981bf6d7679bce273a4689937ef20d60d1257fc0897d1d7fd7179daf6c316` |
| `cluster_maps/junyi_timed_cooc_item_to_cluster.json` | `5dfc3e134cd5d64db4c7a5224a026be162a5db78054455c4fe617ccffa44b69e` |
| `cluster_maps/assistments_{text,item}_to_cluster.json` | `7676e8dbe9a90c309c3e2578526c81f85688ef1088dd6a8c7327b74596225327` |
| `cluster_maps/assistments_cooc_item_to_cluster.json` | `e82d2ba2217a792b4fe4ed3ce45b5c2fe5634d258c27934c9f02dccc69e6a159` |
| `cluster_maps/xes3g5m_{cooc,item}_to_cluster.json` | `097696754951b49fceaa4369ee45f4cd7adf6dae75ec6c8cc93ade21fa5f018d` |

## After OSF/Zenodo succeeds — record here

| Field | Value |
| --- | --- |
| Registration URL | _paste_ |
| DOI | _paste_ |
| Timestamp (UTC) | _paste_ |

Then **once**:

```bash
PYTHONPATH=. python3 scripts/run_freeze_partition_replication.py --touch-test
PYTHONPATH=. python3 scripts/build_paper_assets.py
python3 scripts/build_dataflow_report.py --mode=slim
python3 scripts/build_dataflow_report.py --mode=full
```

Do **not** hand-edit H-rev claim cells. Do **not** re-touch without `TOUCH_TEST_OVERRIDE:` in `docs/DEVIATIONS.md`.
